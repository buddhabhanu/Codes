/****** Object:  Table [dbo].[FORECAST_DETAIL_HIST]    Script Date: 08/27/2013 16:20:35 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- drop table [FORECAST_DETAIL_HIST_BAK]
CREATE TABLE [dbo].[FORECAST_DETAIL_HIST_BAK](
	[APPLICATION_SEQUENCE] [bigint] IDENTITY(2246929761,1) NOT NULL,
	[FDD_ID] [int] NOT NULL,
	[AUDIT_ID] [int] NOT NULL,
	[VALUE] [numeric](19, 6) NULL,
	CONSTRAINT [PK_FORECAST_DETAIL_HIST_BAK] PRIMARY KEY CLUSTERED 
	(
		[APPLICATION_SEQUENCE] ASC
	)
)
GO

-- 
Declare @AppSeqMin bigint,
		@AppSeqMax bigint,
		@threshold bigint
		
Select  @AppSeqMin = 0,
		@AppSeqMax = 10000000,
		@threshold = 10000000



 -- Now Loop through until we transfer all the data  
 set identity_insert [FORECAST_DETAIL_HIST_BAK] on  
  


WHILE EXISTS ( SELECT * FROM FORECAST_DETAIL_HIST  )
	BEGIN 
	
			DELETE FROM dbo.[FORECAST_DETAIL_HIST]
				OUTPUT 
					DELETED.APPLICATION_SEQUENCE,
					DELETED.FDD_ID,
					DELETED.AUDIT_ID,
					DELETED.VALUE
				INTO [dbo].[FORECAST_DETAIL_HIST_BAK]
				(
					APPLICATION_SEQUENCE
					,FDD_ID
					,AUDIT_ID
					,VALUE
				)
			WHERE APPLICATION_SEQUENCE BETWEEN @AppSeqMin and @AppSeqMax
	
	SELECT @@ROWCOUNT , @AppSeqMin, @AppSeqMax

	-- Set iterator the 
		Select  @AppSeqMin 
			= @AppSeqMax+1
			
		Select
			@AppSeqMax = @threshold + @AppSeqMax

	END 
		
set identity_insert [FORECAST_DETAIL_HIST_BAK] off  
  
  
  
-- After move rename the table 
-- rname old table
EXEC sp_rename 'FORECAST_DETAIL_HIST', 'FORECAST_DETAIL_HIST_OLD';  

EXEC sp_rename 'FORECAST_DETAIL_HIST_BAK', 'FORECAST_DETAIL_HIST';  
  
  
/*
--Enable teh FKs again

ALTER TABLE [dbo].[FORECAST_DETAIL_HIST_BAK]  WITH CHECK ADD  CONSTRAINT [RefEFM_AUDIT1034_BAK] FOREIGN KEY([AUDIT_ID])
REFERENCES [dbo].[EFM_AUDIT] ([AUDIT_ID])
GO

ALTER TABLE [dbo].[FORECAST_DETAIL_HIST_BAK] CHECK CONSTRAINT [RefEFM_AUDIT1034_BAK]
GO

ALTER TABLE [dbo].[FORECAST_DETAIL_HIST_BAK]  WITH CHECK ADD  CONSTRAINT [RefFORECAST_DETAIL_DATA_B2286_BAK] FOREIGN KEY([FDD_ID])
REFERENCES [dbo].[FORECAST_DETAIL_DATA_B] ([FDD_ID])
GO

ALTER TABLE [dbo].[FORECAST_DETAIL_HIST_BAK] CHECK CONSTRAINT [RefFORECAST_DETAIL_DATA_B2286_BAK]
GO





*/  
  