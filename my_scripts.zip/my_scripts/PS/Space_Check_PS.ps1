﻿param
(
    [parameter(Mandatory = $true)]
    [Alias("HostName", "SeverName")]
    [string[]] $ComputerName ,
    [parameter(Mandatory = $false)]
    [Alias("DriveName", "MountName")]
    [string] $DiskName
)
$ServersNotReachable = @()

$ComputerName | ForEach-Object {

$count =Test-Connection $_ -Count 1 -Quiet -ErrorAction SilentlyContinue

    if ($true -eq $count)
  {  
     if($null -eq $DiskName)
{

$Records=Get-CimInstance -ClassName Win32_Volume -ComputerName $ComputerName | Where-Object {$_.Drivetype -eq 3  -and $_.Caption -notlike "*\\?\*" -and $_.Label -ne "System"}| sort-object Freespace -Descending | Select @{Label="NodeName"; Expression={$_.SystemName}},
@{Label="SQLInstance"; Expression={$_.PSComputerName}},@{Label="MountName"; Expression={$_.Caption}},@{Label="Total SIze(GB)";Expression={$_.Capacity / 1gb -as [int] }}, 
@{Label="FreeSpace(GB)"; Expression={$_.FreeSpace / 1gb -as [int] }},@{Label="DiskLabel"; Expression={$_.Label}}
$Records

} 
else
{
$Records=Get-CimInstance -ClassName Win32_Volume -ComputerName $ComputerName | Where-Object {$_.Drivetype -eq 3 -and $_.Caption -like "*$DiskName*" }| sort-object Freespace -Descending | Select @{Label="NodeName"; Expression={$_.SystemName}},
@{Label="SQLInstance"; Expression={$_.PSComputerName}},@{Label="MountName"; Expression={$_.Caption}},@{Label="Total SIze(GB)";Expression={$_.Capacity / 1gb -as [int] }}, 
@{Label="FreeSpace(GB)"; Expression={$_.FreeSpace / 1gb -as [int] }},@{Label="DiskLabel"; Expression={$_.Label}} 
$Records

  }

  
 
   } 
   
else
    {
        $ServersNotReachable += $_ 
        Write-Host "The server(s) below is/are not reachable..." -ForegroundColor Red
        $ServersNotReachable
        
    }
}