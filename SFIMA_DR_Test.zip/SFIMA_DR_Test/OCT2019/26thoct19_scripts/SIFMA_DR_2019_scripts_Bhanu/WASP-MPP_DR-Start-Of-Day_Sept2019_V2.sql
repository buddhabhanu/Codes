-- change primary and secondary id's to consolidate 8 servers to 6.
Update [WASP].[dbo].[USER_CFG_CTCI] set PRIMARYID=101, SECONDARYID=103 where PRIMARYID in (101,102)
Update [WASP].[dbo].[USER_CFG_CTCI] set PRIMARYID=103, SECONDARYID=101 where PRIMARYID in (103,104)

-- FIX_PROPERTIES
truncate table [WASP].[dbo].[FIX_PROPERTIES]
Insert into [WASP].[dbo].[FIX_PROPERTIES] values (
			101,1,1,7,8,3,6000,'jdbc:sqlserver://159.79.40.95:1198;databaseName=WASP;SelectMethod=cursor','Y','Y',NULL,NULL,NULL,NULL,NULL,NULL,'N','N','N',100)
Insert into [WASP].[dbo].[FIX_PROPERTIES] values (
			103,1,1,7,8,3,6000,'jdbc:sqlserver://159.79.40.95:1198;databaseName=WASP;SelectMethod=cursor','Y','Y',NULL,NULL,NULL,NULL,NULL,NULL,'N','N','N', 100)
Insert into [WASP].[dbo].[FIX_PROPERTIES] values (
			105,1,1,8,7,3,6000,'jdbc:sqlserver://159.79.40.95:1198;databaseName=WASP;SelectMethod=cursor','Y','Y',NULL,NULL,NULL,NULL,NULL,NULL,'N','N','N', 2000)
Insert into [WASP].[dbo].[FIX_PROPERTIES] values (
			106,1,1,8,7,3,6000,'jdbc:sqlserver://159.79.40.95:1198;databaseName=WASP;SelectMethod=cursor','Y','Y',NULL,NULL,NULL,NULL,NULL,NULL,'N','N','N', 2000)
Insert into [WASP].[dbo].[FIX_PROPERTIES] values (
			107,1,1,8,7,3,6000,'jdbc:sqlserver://159.79.40.95:1198;databaseName=WASP;SelectMethod=cursor','Y','Y',NULL,NULL,NULL,NULL,NULL,NULL,'N','N','N', 100)
Insert into [WASP].[dbo].[FIX_PROPERTIES] values (
			108,1,1,8,7,3,6000,'jdbc:sqlserver://159.79.40.95:1198;databaseName=WASP;SelectMethod=cursor','Y','Y',NULL,NULL,NULL,NULL,NULL,NULL,'N','N','N', 100)

-----------------------------------------------------------------------------
-- RDB_CONFIG
truncate table [WASP].[dbo].[RDB_CONFIG]
Insert into [WASP].[dbo].[RDB_CONFIG] values (7, '159.79.40.50', 54311, 54312)
Insert into [WASP].[dbo].[RDB_CONFIG] values (8, '159.79.40.51', 54311, 54312)

-----------------------------------------------------------------------------
-- MPPServerProperties
truncate table [WASP].[dbo].[MPPServerProperties]
Insert into [WASP].[dbo].[MPPServerProperties] values (101, '192.168.60.80',  7000)
Insert into [WASP].[dbo].[MPPServerProperties] values (103, '192.168.60.81',  7000)
Insert into [WASP].[dbo].[MPPServerProperties] values (105, '192.168.60.83', 7000)
Insert into [WASP].[dbo].[MPPServerProperties] values (106, '192.168.60.82',  7000)
Insert into [WASP].[dbo].[MPPServerProperties] values (107, '192.168.60.136', 7000)
Insert into [WASP].[dbo].[MPPServerProperties] values (108, '192.168.60.135',  7000)

-----------------------------------------------------------------------------
-- [FrameworkConnectors]
update [WASP].[dbo].[FrameworkConnectors] set PrimaryAddress='159.79.96.3', secondaryAddress='159.79.96.3' where connectortype='ADFO'
update [WASP].[dbo].[FrameworkConnectors] set PrimaryAddress='159.79.104.9', secondaryAddress='159.79.104.9' where connectortype='ADFQ'
update [WASP].[dbo].[FrameworkConnectors] set PrimaryAddress='159.79.96.3', secondaryAddress='159.79.96.3' where connectortype='ADFT'
update [WASP].[dbo].[FrameworkConnectors] set PrimaryAddress='159.79.96.9', secondaryAddress='159.79.96.9' where connectortype='CA_TRADE'
update [WASP].[dbo].[FrameworkConnectors] set PrimaryAddress='159.79.96.10', secondaryAddress='159.79.96.10' where connectortype='SP_TRADE'
update [WASP].[dbo].[FrameworkConnectors] set PrimaryAddress='159.79.104.20', secondaryAddress='159.79.104.20' where connectortype='ORF'
update [WASP].[dbo].[FrameworkConnectors] set PrimaryAddress='159.79.96.43', secondaryAddress='159.79.96.43' where connectortype='TS'
update [WASP].[dbo].[FrameworkConnectors] set PrimaryAddress='159.79.96.10', secondaryAddress='159.79.96.10' where connectortype='TRF_NQ'
update [WASP].[dbo].[FrameworkConnectors] set PrimaryAddress='159.79.96.10', secondaryAddress='159.79.96.10' where connectortype='TRF_NY'
update [WASP].[dbo].[FrameworkConnectors] set PrimaryAddress='159.79.96.10', secondaryAddress='159.79.96.10' where connectortype='TRF_NC'

-----------------------------------------------------------------------------
-- MQ
truncate table [WASP].[dbo].[MQ_QMGR_CFG]
Insert into [WASP].[dbo].[MQ_QMGR_CFG] VALUES ('MPP_MQ_MGR_1','206.200.28.112',1419,'MQMPP01','CTCI.DEF.SVRCONN')
