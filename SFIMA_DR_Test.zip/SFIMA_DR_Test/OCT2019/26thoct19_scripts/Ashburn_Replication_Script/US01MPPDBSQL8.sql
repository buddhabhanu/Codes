/****** Scripting replication configuration ******/
/****** Please Note: For security reasons, all password parameters were scripted with either NULL or an empty string. ******/

/****** Begin: Script to be run at Distributor ******/

/****** Installing the server as a Distributor ******/
use master
exec sp_adddistributor @distributor = N'US01MPPDBSQL8\US01MPPDBSQL8', @password = N'Nasdaq@1234567'
GO

-- Adding the agent profiles
-- Updating the agent profile defaults
exec sp_MSupdate_agenttype_default @profile_id = 1
GO
exec sp_MSupdate_agenttype_default @profile_id = 2
GO
exec sp_MSupdate_agenttype_default @profile_id = 4
GO
exec sp_MSupdate_agenttype_default @profile_id = 6
GO
exec sp_MSupdate_agenttype_default @profile_id = 11
GO

-- Adding the distribution databases
use master
exec sp_adddistributiondb @database = N'distribution', @data_folder = N'X:\SQL_Data\Data', @data_file = N'distribution.MDF', @data_file_size = 15000, @log_folder = N'X:\SQL_Log\Log', @log_file = N'distribution.LDF', @log_file_size = 7380, @min_distretention = 0, @max_distretention = 72, @history_retention = 48, @deletebatchsize_xact = 5000, @deletebatchsize_cmd = 2000, @security_mode = 1
GO

/****** End: Script to be run at Distributor ******/

-- Adding the distribution publishers
exec sp_adddistpublisher @publisher = N'APMPPDBSQL12\APMPPDBSQL12', @distribution_db = N'distribution', @security_mode = 1, @working_directory = N'X:\MSSQL12.US01MPPDBSQL8\MSSQL\ReplData', @trusted = N'false', @thirdparty_flag = 0, @publisher_type = N'MSSQLSERVER'
GO
exec sp_adddistpublisher @publisher = N'US01MPPDBSQL10\US01MPPDBSQL10', @distribution_db = N'distribution', @security_mode = 1, @working_directory = N'X:\MSSQL12.US01MPPDBSQL8\MSSQL\ReplData', @trusted = N'false', @thirdparty_flag = 0, @publisher_type = N'MSSQLSERVER'
GO
exec sp_adddistpublisher @publisher = N'US01MPPDBSQL11\US01MPPDBSQL11', @distribution_db = N'distribution', @security_mode = 1, @working_directory = N'X:\MSSQL12.US01MPPDBSQL8\MSSQL\ReplData', @trusted = N'false', @thirdparty_flag = 0, @publisher_type = N'MSSQLSERVER'
GO
exec sp_adddistpublisher @publisher = N'US01MPPDBSQL7\US01MPPDBSQL7', @distribution_db = N'distribution', @security_mode = 1, @working_directory = N'X:\MSSQL12.US01MPPDBSQL8\MSSQL\ReplData', @trusted = N'false', @thirdparty_flag = 0, @publisher_type = N'MSSQLSERVER'
GO
exec sp_adddistpublisher @publisher = N'US01MPPDBSQL9\US01MPPDBSQL9', @distribution_db = N'distribution', @security_mode = 1, @working_directory = N'X:\MSSQL12.US01MPPDBSQL8\MSSQL\ReplData', @trusted = N'false', @thirdparty_flag = 0, @publisher_type = N'MSSQLSERVER'
GO






